import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import Swal from 'sweetalert2';
import { BatchDataAnalysisService } from './batch-data-analysis.service';
import { DataVaultService } from '../data-vault/data-vault.service';
import { MatDialog } from '@angular/material/dialog';
import { BatchDataAnalysisConfirmDialogComponent } from '../batch-data-analysis-confirm-dialog/batch-data-analysis-confirm-dialog.component';
import { JsonPipe } from '@angular/common';
declare let Plotly: any;



@Component({
  selector: 'app-batch-data-analysis',
  templateUrl: './batch-data-analysis.component.html',
  styleUrls: ['./batch-data-analysis.component.scss'],
})
export class BatchDataAnalysisComponent implements OnInit {
  @ViewChild('chatContainer') private chatContainer!: ElementRef;
  messages: Message[] = [];
  userInput: string = '';
  test: boolean = false;
  lastData: any;
  loader: boolean = false;
  dataArr: any;
  title: any;
  isLastData: boolean = false;
  loadLastData: any;
  loadLastDataq: any;
  isImageDisplayed: boolean = true;
  errorMessage: any;
  isPageDataLoading: boolean = false;
  isLatestSearchInProgress:boolean = false;
  isApiRequestInProgress: boolean = false;
  selectedFolder: string = ''; 
  selectedFiles: string = ''; 
  token: any;
  fileData:any;
  folderData:any;
  disableModel: boolean = false;
  userName: any;
  isDataSource : boolean = false;
  constructor(
    private batchDataAnalysisService: BatchDataAnalysisService,
    private el: ElementRef ,private dataVaultService:DataVaultService,private dialog: MatDialog
  ) { this.token = JSON.parse(localStorage.getItem('token') || '{}');
  this.userName = JSON.parse(localStorage.getItem('username') || '{}');
}
  ngOnInit(): void {
    this.getLastData();
    this.onPageRefresh();
    this.getFolderList();
  }
  sendMessage(): void {
    this.errorMessage = ''
    this.test = false;
    this.isLastData = false;
    if (this.userInput.trim() === '') return;
    const chartContainer =
      this.el.nativeElement.querySelector('.chart-container');
    chartContainer.innerHTML = '';
    const body = {
      uuid: "rca_auth_token",
      username : this.userName,
      data_vault : this.selectedFolder,
      csv_file: this.selectedFiles,
      source_type : 'synres',
      user_prompt : this.userInput,
      is_analyser : true
    };
    this.messages = [];
    const questionText = `${this.userInput}`;
    const question: Message = { text: questionText, type: 'question' };
    this.messages.push(question);
    this.loader = true;
    this.batchDataAnalysisService.sendMessage(body).subscribe((response) => {
      const responseData = JSON.parse(response);
      console.log("-------stringiojdioes76872e9287e97e09o9",responseData)
      this.errorMessage = null;
      this.loader = false;
      this.isImageDisplayed = false;
      this.getLastData();
      const answerText = `${responseData.text_answer}`;
      const answer: Message = { text: answerText, type: 'answer' };
      this.dataArr = responseData.charts;
      this.messages.push(answer);
      
      this.renderGraph();
    },
    error=>{
      this.loader = false;
      this.messages = [];
      Swal.fire({
        title: 'Error',
        text: error,
        width: '500px', 
        heightAuto: false,
        confirmButtonColor: "#235D9F",
      } as any);
        });
        // this.userInput = '';
        // this.selectedFolder = '';
        // this.selectedFiles = ''; 
       }

  renderGraph() {
    const chartContainer = this.el.nativeElement.querySelector('.chart-container');
    if (!chartContainer) {
      return;
    }
    chartContainer.innerHTML = '';
    
    this.dataArr.forEach((chartData: string, index: number) => {
      try {
        const each = JSON.parse(chartData);
        const plotData = each.data;
        let plotLayout = each.layout;
        this.title = plotLayout.title.text;
        plotLayout.title.text = '';
        plotLayout.modeBar = false;
  
        if (plotData.length > 0) {
          const containerDiv = document.createElement('div');
          const titleElement = document.createElement('h4');
          titleElement.style.backgroundColor = '#DBDFE2';
          titleElement.style.padding = '12px';
          titleElement.style.margin = '0px';
          titleElement.textContent = this.title;
          containerDiv.appendChild(titleElement);
          containerDiv.style.width = '100%';
          containerDiv.style.marginBottom = '20px';
          containerDiv.style.border = '1px solid #DBDFE2';
          chartContainer.appendChild(containerDiv);
          
          const plotDiv = document.createElement('div');
          plotDiv.id = 'plot' + index;
          containerDiv.appendChild(plotDiv);
  
          const config = { displayModeBar: true, responsive: true };
          Plotly.newPlot('plot' + index, plotData, plotLayout, config);
        } else {
          // Handle the case when plotData is empty
        }
      } catch (error) {
        console.error('Error parsing chart data:', error);
      }
    });
  }
  latestSearch(input: any) {
    if (!this.isApiRequestInProgress) {
      this.isApiRequestInProgress = true;
    this.test = false;
    this.dataArr = '';
    const questionText = `${input}`;
    const body = {
      uuid: "rca_auth_token",
      username : this.userName,
      data_vault : this.selectedFolder,
      csv_file: this.selectedFiles,
      source_type : 'synres',
      user_prompt : input,
      response_data:'',
      is_analyser : false
    };
    this.messages = [];
    const question: Message = { text: questionText, type: 'question' };
    this.messages.push(question);
    this.batchDataAnalysisService.sendMessage(body).subscribe((recentData) => {
      const latestSearchData = JSON.parse(recentData)
      console.log("11111111111111111",recentData)
      const answerText = `${latestSearchData.text_answer}`;
      const answer: Message = { text: answerText, type: 'answer' };
      this.messages.push(answer);
      this.dataArr = latestSearchData.charts;
      this.renderGraph();
      this.isApiRequestInProgress = false;
    });
  }
  }
  getLastData() {
    this.batchDataAnalysisService.sendLastFiveRecords(this.userName).subscribe((ele) => {
      this.lastData = ele.data;
      console.log("---lasttttttttt",this.lastData)
      if (this.lastData.length == 0) {
        this.isLastData = true;
        this.isImageDisplayed = true;
        this.isPageDataLoading = false;
      } else {
        this.isLastData = false;
        this.isImageDisplayed = false;
      }
    });
  }
  onPageRefresh() {
    this.batchDataAnalysisService.sendLastFiveRecords(this.userName).subscribe((ele) => {
      console.log("mmmmmm",ele)
      this.lastData = ele.data;
      this.loadLastData = this.lastData[0];
      console.log("BBBBBBBBBBBB",this.loadLastData)
      console.log("mmmmmmwwww",this.messages)

      const question: Message = {
        text: this.loadLastData.user_prompt,
        type: 'question',
      };
      this.messages.push(question);
      const answer: Message = {
        text: this.loadLastData.response_data.text_answer,
        type: 'answer',
      };
      console.log("messagesmessagesmessages",this.messages)

      let codeData = this.loadLastData.response_data.charts
     this.dataArr = codeData;
     this.messages.push(answer);
     this.isPageDataLoading = false;
     this.renderGraph();
    });
  }
  toggleImageDisplay() {
    const leftDiv = document.querySelector('.left-div');
    if (leftDiv) {
      if (this.isImageDisplayed) {
        leftDiv.classList.add('image-displayed');
      } else {
        leftDiv.classList.remove('image-displayed');
      }
    }
  }
  
  getFolderList() {
    let body ={
      "username":this.userName
    }
    this.dataVaultService.getFolderList(this.token,body, (result: any) => {
      this.folderData = result.folders.map((folderName: string) => folderName.replace('/', ''));
      console.log("----",this.folderData)
    })
  }
getFilesList(folderName:any)
{
  console.log('Calling getFilesList for folder:', folderName);
 let body = {
  username:this.userName,
  select_folder: folderName
  }
  console.log("filebody",body);
  this.dataVaultService.getFileList(this.token,body,(result=>{
    this.fileData = result.files;
  }))
}
onFolderSelection(selectedFolder: any) {
  if (selectedFolder) {
      this.getFilesList(selectedFolder);
  }
}
verifyDataSource()
{
  const body = {
    uuid: "rca_auth_token",
    username : this.userName,
    data_vault : this.selectedFolder,
    csv_file: this.selectedFiles,
    source_type : 'synres',
    is_analyser : true,
    user_prompt : ''
  };
  const dialogRef = this.dialog.open(BatchDataAnalysisConfirmDialogComponent,{
    width: '460px',
    height: '152px',
    data: {}
  })
  dialogRef.afterClosed().subscribe(result => {
    if(result == true){
    this.batchDataAnalysisService.sendMessage(body).subscribe(response=>{
      console.log("---response",response);
      if(response)
      {
        console.log('kkkk', response.status);
        this.isDataSource = true;
      }
    })
  }
  else{
    console.log('The dialog was canceled or closed');
  }
    });
}
}
interface Message {
  text: string;
  type: 'question' | 'answer';
}

