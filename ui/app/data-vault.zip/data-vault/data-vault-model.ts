export interface dataVaultModel {
    name: string;
    modifiedOn: string;
    modifiedBy: string;
    size: number;
    selected: boolean;
  }
  