import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { FileService } from '../file-management/file-management.service';
import { FileElement } from '../file-management/model/element';
import { HttpClient } from '@angular/common/http';
import { DataVaultService } from './data-vault.service';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';

@Component({
  selector: 'app-data-vault',
  templateUrl: './data-vault.component.html',
  styleUrls: ['./data-vault.component.scss']
})
export class DataVaultComponent implements OnInit {
displayedColumns : String[] = ['select','name','modifiedOn','modifiedBy','size'];
selection = new SelectionModel<any>;
dataSource = new MatTableDataSource<any>
 constructor(private http : HttpClient,private dataVaulrService : DataVaultService)
 {}
 ngOnInit(): void {
   this.getfolderData();
 }
 apiURL = 'assets/json/data-vault-folder.json'
 getfolderData()
 {
  this.dataVaulrService.getfolderData().subscribe((data:any)=>{
    let folderData = data.data.features
    this.dataSource = folderData;
  })
 }
 masterToggle() {
  this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
}

// Add this method to check if all rows are selected
isAllSelected() {
  const numSelected = this.selection.selected.length;
  const numRows = this.dataSource.data.length;
  return numSelected === numRows;
}
}
