import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataVaultService {
  constructor(private http : HttpClient)
  {}
  apiURL = 'assets/json/data-vault-folder.json'
  getfolderData()
  {
   return this.http.get(this.apiURL);
  }
}
