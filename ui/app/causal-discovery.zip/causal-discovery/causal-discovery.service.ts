import { HttpClient, HttpHeaders } from '@angular/common/http';

 

import { Injectable } from '@angular/core';

 

import { EnvService } from '../env.service';

 

import { API_URL } from '../utils/api-list';

 

 

 

@Injectable({

 

  providedIn: 'root'

 

})

 

export class CausalDiscoveryService {

 

  token: any;

 

  httpHeader: { Authorization: string; };

 

 

 

  constructor( private http: HttpClient,public env: EnvService,) {

 

    this.token = JSON.parse(localStorage.getItem("token") || '{}');

 

    console.log('this.token', this.token);

 

    this.token = JSON.parse(localStorage.getItem("token") || '{}');

 

 

 

        this.httpHeader = { 'Authorization': `Token ${this.token}` };

 

   }

 

 

 

  createAuthorizationHeader(token: any): any {

 

    console.log("token in header",token);

 

    const headers = new HttpHeaders({

 

      'Content-Type': 'application/json',

 

      Authorization: `Token ${token}`,

 

    });

 

    return headers;

 

  }

 

 

 

  getFiles(token: any, callback: (data: any) => void) {

 

   

 

    this.http.get<any>(`${this.env.apiUrl}${API_URL.getFiles}`, {

 

      headers: this.createAuthorizationHeader(token)

 

    }).subscribe((result: any) => {

 

     

 

     callback(result);

 

  }

 

 

 

);

 

  }

 

  getBatches(token:any, callback:(data:any)=>void){

    this.http.get<any>(`${this.env.apiUrl}${API_URL.getBatches}`,{

      headers:this.createAuthorizationHeader(token)

    }).subscribe((result:any)=>{

      callback(result);

    })

  }

 

 

  getRecords(token: any,body:any, callback: (data: any) => void) {

 

      console.log('getColumnHeaders  service token59 ',body);

 

      this.http.post<any>(`${this.env.apiUrl}${API_URL.getRecords}`,body, {

 

        headers: this.createAuthorizationHeader(token)

 

      }).subscribe((result: any) => {

 

        console.log('109', result);

 

       // this.data = result;

 

       callback(result);

 

    }

 

  );

 

    }

 

    getTarget(token: any,body:any, callback: (data: any) => void) {

      console.log('getColumnHeaders  service token59 ',body);

      this.http.post<any>(`${this.env.apiUrl}${API_URL.getcolumnheaders}`,body, {

        headers: this.createAuthorizationHeader(token)

      }).subscribe((result: any) => {

        console.log('getColumnHeaders results', result);

       // this.data = result;

       callback(result);

    }

  );

  }

  getXAI(token: any,body:any, callback: (data: any) => void) {

    console.log('getColumnHeaders  service token59 ',body);

    this.http.post<any>(`${this.env.apiUrl}${API_URL.getXAI}`,body, {

      headers: this.createAuthorizationHeader(token)

    }).subscribe((result: any) => {

      console.log('137', result);

     // this.data = result;

     callback(result);

  }

);

}

 

getCausalgraph(token: any,body:any, callback: (data: any) => void) {

  console.log('getCausalgraph  service token59 ',body);

  this.http.post<any>(`${this.env.apiUrl}${API_URL.getCausalGraph}`,body, {

    headers: this.createAuthorizationHeader(token)

  }).subscribe((result: any) => {

    console.log('137', result);

   // this.data = result;

   callback(result);

}

);

}
getColumnValues(token: any,body:any, callback: (data: any) => void) {
  console.log('getColumnHeaders  service token67 ',body);
  this.http.post<any>(`${this.env.apiUrl}${API_URL.getcolumnvalues}`,body, {
    headers: this.createAuthorizationHeader(token)
  }).subscribe((result: any) => {
    console.log('getColumnHeaders results 71', result);
   // this.data = result;
   callback(result);
}
);

}
getWhatIfPrediction(token: any,body:any, callback: (data: any) => void) {
  console.log('303 ',body);

  const headers = new HttpHeaders().set('Authorization', 'Token ' + token);
  console.log('304 ',`${this.env.apiUrl}${API_URL.getWhatIFPredication}`,headers);
  this.http.post<any>(`${this.env.apiUrl}${API_URL.getWhatIFPredication}`,body, {
    headers
  }).subscribe((result: any) => {
    console.log('getColumnHeaders results 71', result);
   // this.data = result;
   callback(result);
}
);

}
getColumnRanges(token: any,body:any, callback: (data: any) => void) {

  console.log('319 ',body);

  this.http.post<any>(`${this.env.apiUrl}${API_URL.getColumnRanges}`,body, {

    headers: this.createAuthorizationHeader(token)

  }).subscribe((result: any) => {

    console.log('327', result);

   // this.data = result;

   callback(result);

}

);

}
}