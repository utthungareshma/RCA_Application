import { Component, OnInit ,ElementRef, ViewChild} from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Data, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { FileUploadComponent } from '../file-upload/file-upload.component'; 
import { CausalDiscoveryService } from './causal-discovery.service';
import { MatTableDataSource } from '@angular/material/table';
declare let Plotly :any

interface Food {
  value: string;
  viewValue: string;
}
interface TopFeatues{
  value: string;
  viewValue: string;
}
interface ModalType{
  value:string;
  viewValue:string;
}
interface EstimatedMethods{
  value:string;
  viewValue:string;
}
interface Refute{
  value:string;
  viewValue:string;
}
interface DObject {
  
  [key: string]: number; // Allow additional properties of type number
}
interface ExcludedData{
  name: string
}
@Component({
  selector: 'app-causal-discovery',
  templateUrl: './causal-discovery.component.html',
  styleUrls: ['./causal-discovery.component.scss']
})
export class CausalDiscoveryComponent implements OnInit{

  typControl: FormControl = new FormControl('regression'); // Change 'default' to your desired default value



  base64Image1!: string ;
 

  disabled = false;
  
  min = 0;
  showTicks = false;
  step = 1;
  thumbLabel = false;
  value: number = 50;
  value1 : number = 20;
  value2: any = 90;
  value3: any = 90;
  value4: any = 90;
   myForm: FormGroup;
   causalForm:FormGroup;
   sliderForm: FormGroup;
   PredictedPenicillinConcentrationForm:FormGroup;
 records: any;
 targets: any;
 InputVariables: any;
 imageUrl!: any;
 selectedFileName!:any;
 selectRecord!:any;
 selectedTarget!:any;
 showImage: boolean=false;
 isLoading : boolean=false;
 causalPlotData: boolean=false;
 selectedCommonCause: any = [];
  selectedTreatment: any = [];
  selectedTargetValues: any = [];
  resultlist: any;
  displayedColumns: string[] = ['feature', 'value', 'impact'];
  dataSource!: MatTableDataSource<any>;
  resultSet: any;
  modelType: any;
  setTargetValue: any;
  filteredResultList: any;
  foods: Food[] = [
    {value: 'steak-0', viewValue: 'BioReactor'},

    {value: 'pizza-1', viewValue: 'PH'},

    {value: 'tacos-2', viewValue: 'CPP'},

  ];
  modals: ModalType[]=[
    {value: 'classification', viewValue: 'Classification' },
    {value: 'regression', viewValue: 'Regression' }
   ];

   topFeatures: TopFeatues[]=[

    {value: '1', viewValue: '1' },

    {value: '2', viewValue: '2' },

    {value: '3', viewValue: '3' },

    {value: '4', viewValue: '4' },

    {value: '5', viewValue: '5' },

    {value: '6', viewValue: '6' },

   ];
   estimatedMethods:EstimatedMethods[]=[
    {value: 'backdoor.linear_regression', viewValue: 'backdoor.linear_regression' },

    {value: 'backdoor.distance_matching', viewValue: 'backdoor.distance_matching' },

    {value: 'backdoor.propensity_score_stratification', viewValue: 'backdoor.propensity_score_stratification' },

    {value: 'backdoor.propensity_score_weighting', viewValue: 'backdoor.propensity_score_weighting' },
   ]
refute:Refute[]=[
  {value: 'random_common_cause', viewValue: 'random_common_cause' },

  {value: 'bootstrap_refuter', viewValue: 'bootstrap_refuter' },

  {value: 'data_subset_refuter', viewValue: 'data_subset_refuter' },

 ]

 excludedCPP: ExcludedData[] = [
  {name: 'Time (h)'},  
  {name: 'Time'},  
  {name: 'Batch reference(Batch_ref:Batch ref)'},
 ]
 
 excludedtargetValues: ExcludedData[] = [
 
  {name: 'XXA18902'},  
  {name: 'KPV18918'},  
  {name: 'KPV18942'},  
  {name: 'M73701'},  
  {name: 'KPV84318'},  
 ]

  ProjectID: any;
  token: any;
  Data:any;
  Batch:any;
  CPP:any;
  result: any;
  causes:  any;
  treatementLists:any;
  targetVar: any;
  causalTargets:  any;
  resultSliderDAta: any;
  calculateButtonEnable:boolean =false;
  batchTargetEnable:boolean =true;
  Target:  any;
  selectedData: Data | any;
  loader: boolean = false;
  causalData: any;
  finalSliderValues: any[] = [];
  getcolumnranges :any;
  disableModel: boolean = false;
  disableTargetField: boolean = false;
  targetValue: any;

  constructor(private formBuilder: FormBuilder,public router: Router,private dialog: MatDialog,private causalDiscoveryService:CausalDiscoveryService) {
    this.token = JSON.parse(localStorage.getItem("token") || '{}');
    this.myForm = this.formBuilder.group({
      project:  ['', Validators.required],
      typ:  ['', Validators.required],
      batch:  ['',],
      index:  ['', ],
      target:  ['', Validators.required],
      ip:  ['', Validators.required],
      num_ft: ['', Validators.required],
      target1:  ['',],
      refute:'',
      estimated_effect: '',
      new_effect:'',
      p_value:''
    });

    this.sliderForm= this.formBuilder.group({
      sugarRate: '',
      ph: '',
      temprature: '',
      pressure: '',
      mixingSpeed: '',
    });


    this.causalForm=this.formBuilder.group({
      file_name: ['',Validators.required],
      selected_batch:  ['', Validators.required],
      treatment_list:  ['', Validators.required],
      common_causes:  ['', Validators.required],
      target_var:  ['', Validators.required],
      estimate_method:  ['', Validators.required],
      causal_target:  ['', Validators.required],
      refute_method:  ['', Validators.required],
      PredictedPenicillinConcentration:'',
      refute:'',
      estimated_effect: '',
      new_effect:'',
      p_value:''
    })
    this.PredictedPenicillinConcentrationForm=this.formBuilder.group({
      PredictedPenicillinConcentration: ''
     
    })

  }



  ngOnInit(): void {

    this.getFiles();

    this.getBatches();
    this.dataSource = new MatTableDataSource( this.resultSliderDAta);
    
  }

 
  uploadFile(): void {
    const dialogRef = this.dialog.open(FileUploadComponent, {
      width: '50%',
    });}
  fileUpload(){
    this.router.navigate(['/fileUpload'])
  }
  getFiles() {
 
   
    const test = this.causalDiscoveryService.getFiles(this.token, (result: any) => {
      let array = [];

      for (const iterator of result.data) {
        let jsonData = {
          "name": iterator
        };
        array.push(jsonData)
      }
      this.Data = array;
    });
  }

  getBatches(){
    const test=this.causalDiscoveryService.getBatches(this.token,(result:any)=>{
      let array=[];
      for(const iterator of result.data){
        let jsonData={
          "name":iterator
        }
        array.push(jsonData)
      }
      this.Batch=array;
    })
  }
  bar(){
    const  data = [{
      type: 'bar',
      x: [20, 14, -23],
      y: ['Suger Rate', 'ph', 'temp'],
      orientation: 'h'
    }];
    Plotly.newPlot('myDiv', data);
  }
  getrecords(event: any){
    const selectedValue = event.value;
    console.log("290",selectedValue);
    let body = {
      "batch_id": selectedValue
    }
    console.log("290",body);
    const test = this.causalDiscoveryService.getRecords(this.token,body, (result: any) => {
      let array = [];
      for (const iterator of result.data) {
        let jsonData = {
          "name": iterator
        };
        array.push(jsonData)
      }
      this.records= array;
      console.log("315",result);
    });

  }
  getTargets(event: any){
    localStorage.setItem('latestfilename',event.value);
    const selectedValue = event.value;
    let body = {
      "file_name": selectedValue
    }
    const test = this.causalDiscoveryService.getTarget(this.token,body, (result: any) => {
      let array = [];
      for (const iterator of result.data) {
        let jsonData = {
          "name": iterator

        };

        array.push(jsonData)

      }

     
//  this.targets = array;
this.resultSet = array;
this.targets = this.resultSet.filter((item1: { name: any; }) => !this.excludedCPP.some((item2: { name: any; }) => item1.name === item2.name));

 this.InputVariables=this.resultSet.filter((item1: { name: any; }) => !this.excludedCPP.some((item2: { name: any; }) => item1.name === item2.name));
    });

  }

  setInputVariables(e:any){
    console.log("SETCPP",e)
    this.setTargetValue = [];
    let jsonData = {
      "name": e.value
    };
    this.setTargetValue.push(jsonData)
    const arr1 = this.InputVariables; //arr1 = tratlist
    this.InputVariables = arr1.filter((item1: { name: any; }) => !this.setTargetValue.some((item2: { name: any; }) => item1.name === item2.name));
   
  }
 
  onChangeData(event: any){
    if(event.value ==="BioreactorData.csv"){
      console.log("Set model ", event)
      this.modelType = this.modals.find(modal => modal.value === 'regression')?.value;
      console.log("280", this.modelType)
      this.disableModel = true;
    }else{
      this.disableModel = false;
      this.modelType = "";
      this.targetValue =  "";
    }
  }
 
  setTargetForModel(event: any){
 
    if(this.myForm.get('project')?.value ==="synres_dataset.csv" && this.myForm.get('typ')?.value === "classification"){
      console.log("Do validation");
      this.targets=this.resultSet.filter((item1: { name: any; }) => !this.excludedCPP.some((item2: { name: any; }) => item1.name === item2.name));
      
      this.targetValue =  "XXA18902";
 
 
    }else if(this.myForm.get('project')?.value ==="synres_dataset.csv" && this.myForm.get('typ')?.value === "regression"){
 
     
      this.targets=this.targets.filter((item1: { name: any; }) => !this.excludedtargetValues.some((item2: { name: any; }) => item1.name === item2.name));
    }
  }
 
 

  getCauses(event: any){

    localStorage.setItem('latestfilename',event.value);

    const selectedValue = event.value;

   

    let body = {

      "file_name": selectedValue

    }
    const test = this.causalDiscoveryService.getTarget(this.token,body, (result: any) => {
      let array = [];

      for (const iterator of result.data) {

        let jsonData = {

          "name": iterator

        };
        array.push(jsonData)

      }
      this.resultlist = array;
      this.filteredResultList = this.resultlist.filter((item1: { name: any; }) => !this.excludedCPP.some((item2: { name: any; }) => item1.name === item2.name));
       this.causes = this.filteredResultList;

       this.treatementLists=this.filteredResultList;

       this.targetVar=this.filteredResultList;

       this.causalTargets=this.filteredResultList;

    

    });
  }

  setTreatement(e:any){
    console.log("Line 314 event", e);
   
    this.selectedCommonCause = [];
    console.log("Value of 2", this.selectedCommonCause)
    for (const iterator of e.value) {
      let jsonData = {
        "name": iterator
      };
      this.selectedCommonCause.push(jsonData)
    }
    console.log("Value of", this.selectedCommonCause)
    const arr1 = this.filteredResultList; //arr1 = tratlist
    const result = arr1.filter((item1: { name: any; }) => !this.selectedCommonCause.some((item2: { name: any; }) => item1.name === item2.name));
    this.treatementLists = result;
    this.setTarget(e);
  }
 
  setTarget(e:any){
    this.selectedTreatment = [];
 
    for (const iterator of e.value) {
      let jsonData = {
        "name": iterator
      };
      this.selectedTreatment.push(jsonData)
    }
    const selectedCauseandTreatment = this.selectedTreatment.concat(this.selectedCommonCause)
    console.log("Selcted non target values ", selectedCauseandTreatment)
 
    const arr1 = this.filteredResultList; //arr1 = tratlist
    const result = arr1.filter((item1: { name: any; }) => !selectedCauseandTreatment.some((item2: { name: any; }) => item1.name === item2.name));
    this.targetVar = result;
    this.setCausalTarget(e);
  }

  setCausalTarget(e:any){
 
    const treatmentList = [];
    for (const iterator of this.causalForm.get('treatment_list')?.value) {
      let jsonData = {
        "name": iterator
      };
      treatmentList.push(jsonData)
    }
 
    const targetList=[];
    for (const iterator of this.causalForm.get('target_var')?.value) {
      let jsonData = {
        "name": iterator
      };
      targetList.push(jsonData)
    }
 
    const resultCausalTargetList = treatmentList.concat(targetList);
    this.causalTargets = resultCausalTargetList;
  }

  calculateXAI() {

    

     const formData = this.myForm.value;

     let body =  formData

    console.log("355",formData);
    const projectValue = this.myForm.get('project')?.value;

  console.log('Project Value383:', this.myForm.get('ip')?.value);
  let body1;
  if(this.myForm.get('project')?.value=="BioreactorData.csv"){

    body1 = {

     "project": "bioreactor",
     "column_names": this.myForm.get('ip')?.value,
 }
 }
 else if(this.myForm.get('project')?.value=="synres_dataset.csv"){

   body1 = {

     "project": "synres",
     "column_names": this.myForm.get('ip')?.value,

 }

 }

 
  let body2;

  if(this.myForm.get('project')?.value=="BioreactorData.csv"){

     body2 = {

      "project": "bioreactor",

      "typ": this.myForm.get('typ')?.value,

      "batch":this.myForm.get('batch')?.value,

      "target": this.myForm.get('target')?.value,

      "ip": this.myForm.get('ip')?.value,

      "index": this.myForm.get('index')?.value,

      "num_ft": this.myForm.get('num_ft')?.value,

  }

  }else if(this.myForm.get('project')?.value=="synres_dataset.csv"){

    body2 = {

      "project": "synres",

      "typ": this.myForm.get('typ')?.value,

      "batch":1,

      "target": this.myForm.get('target')?.value,

      "ip": this.myForm.get('ip')?.value,

      "index": 5,

      "num_ft": this.myForm.get('num_ft')?.value,

  }

  }
   console.log("383",body2);
  

    const test = this.causalDiscoveryService.getXAI(this.token,body2, (result: any) => {

      this.resultSliderDAta=result.data.features;
      console.log("523",this.resultSliderDAta);
      this.dataSource = new MatTableDataSource( this.resultSliderDAta);

      console.log("463",this.resultSliderDAta);
     
      let array: any[] = [];
      for (const iterator of result.data.features) {

        array.push(iterator.Value)
      }
      this.loader = true;
      this.calculateButtonEnable=true;

      let array1 = [];

      for (const iterator of result.data.features) {
        array1.push(iterator.Feature)
      }
      

      let array2: any[] = [];
      for (const iterator of result.data.explanations) {
        array2.push(iterator.impact
          )
      }
      let array6: any[] = [];
      for (const iterator of result.data.explanations) {
        array6.push(iterator.feature
          )
      }
  console.log("400y",array6);

  console.log("400y",array);

  console.log("400x",array1);
  this.loader = false;
  function getColor(value: number) {
    return value >= 0 ? '#89E047' : '#FF664F'; // Set the condition and colors as needed
  }

  const colors = array2.map(value => getColor(value));
    const  data = [{

      type: 'bar',

      x: array2,
      y: array6,
      orientation: 'h',
      
      marker: {
        color: colors // Use the array of colors
      }

    }];

    const layoutFeature = {
      title: 'Feature Impact Plot',
      xaxis: {
        title: ""// Set the x-axis label
      },
      yaxis: {
        title: '',
        automargin: true, // Enable auto margins for the y-axis
      },
      margin: {
        l: 100, // Adjust the left margin to accommodate the y-axis labels
        r: 50,
        b: 100, // Adjust the bottom margin if needed
        t: 50,
      }
      
      
    };
    // var layoutFeature = { 
    //   title: 'Feature Impact Plot',
      
    // };
   
    Plotly.newPlot('impact', data,layoutFeature);

    console.log("400",array);

    console.log("400",array1);
    console.log("500",result.data);

    console.log("500",result.data);

    // console.log("631",result.data.disagree);
    // console.log("632",result.data.Nornmal);

    if (this.myForm.get('project')?.value == "synres_dataset.csv" && this.myForm.get('typ')?.value == "classification" && this.myForm.get('target')?.value == "XXA18902") {
      // console.log("635",result.data.Disagree);
      // console.log("636",result.data.Nornmal);
      const data5 = [{
        type: 'bar',
    
        x: [result.data.Disagree, result.data.Normal],
        y: ['Disagree', 'Normal'],
        orientation: 'h',
        marker: {
    
          color: ['#89E047', ' #0077FF'] // Define your desired colors here
        }
    
      }];
      var layoutRegular = {
        title: 'Probability chart',
    
      };
    
      Plotly.newPlot('regular', data5, layoutRegular);
    } else {
      const data5 = [{
        type: 'bar',
    
        x: [result.data.actual_value, result.data.prediction],
        y: ['Actual', 'Predicted'],
        orientation: 'h',
        marker: {
    
          color: ['#89E047', ' #0077FF'] // Define your desired colors here
        }
    
      }];
      var layoutRegular = {
        title: 'Actual vs Prediction Comparison',
    
      };
    
      Plotly.newPlot('regular', data5, layoutRegular);
    
    }

    // const  data5 = [{
    //   type: 'bar',

    //   x:  [result.data.actual_value,result.data.prediction ],
    //   y: ['Actual','Predicted'],
    //   orientation: 'h',
    //   marker: {

    //     color: ['#89E047', ' #0077FF'] // Define your desired colors here
    //   }

    // }];
    // var layoutRegular = { 
    //   title: 'Actual vs Prediction Comparison',
      
    // };

    // Plotly.newPlot('regular', data5,layoutRegular);


    // const data6 = [{

    //   type: 'table',

    //   header: {

    //     values:[["<b>Feature</b>"], ["<b>value</b>"],

    //     ["<b>Impact</b>"]],

    //     align: "center",

    //     line: {width: 1, color: 'black'},

    //     fill: {color: "grey"},

    //     font: {family: "Arial", size: 12, color: "white"},

    //     columnwidth: [100, 100, 100],

    //     rowheight: 30,
    //   },

    //   cells: {

    //     values: [array1,array,array2],

    //     align: "center",

    //     line: {color: "black", width: 1},

    //     font: {family: "Arial", size: 11, color: ["black"]},
     

    //   }

    // }];
    // var layouttabular = {
    //   title: 'Feature Details',
     
    // };
    // Plotly.newPlot('tabular', data6,layouttabular);

    }); 

  }

 

  getCausal(){

    this.loader = true;

    const formData = this.causalForm.value;

    let body =  formData

    console.log("575",body);

    console.log("file",formData);
    

    let bodyCausal=

    {

      "file_name":this.causalForm.get('file_name')?.value,

      "selected_batch":this.causalForm.get('selected_batch')?.value,

      "treatment_list":this.causalForm.get('treatment_list')?.value,
      "common_causes":this.causalForm.get('common_causes')?.value,
      "target_var":["Penicillin concentration(P:g/L)"],

      "causal_target":this.causalForm.get('causal_target')?.value,

      "estimate_method":this.causalForm.get('estimate_method')?.value,

      "refute_method":this.causalForm.get('refute_method')?.value,

    }

  //   let bodyCausal={

  //     "file_name":"BioreactorData.csv",

  //     "selected_batch":99,

  //     "treatment_list":["Temperature(T:K)", "pH(pH:pH)", "Dissolved oxygen concentration(DO2:mg/L)",

  //     "Oxygen Uptake Rate(OUR:(g min^{-1}))", "Carbon evolution rate(CER:g/h)"],

  //     "common_causes":["Agitator RPM(RPM:RPM)", "Sugar feed rate(Fs:L/h)",

  //     "Water for injection/dilution(Fw:L/h)", "PAA flow(Fpaa:PAA flow (L/h))", "Oil flow(Foil:L/hr)"],

  //     "target_var":["Penicillin concentration(P:g/L)"],

  //     "causal_target":"Penicillin concentration(P:g/L)",

  //     "estimate_method":"backdoor.linear_regression",

  //     "refute_method":"data_subset_refuter"

  // }

 
  this.isLoading = true;
    const test = this.causalDiscoveryService.getCausalgraph(this.token,bodyCausal, (result: any) => {
    
    this.isLoading = false;
    this.causalPlotData=true;
    const plotData = result.plot.data
    this.causalData=result;

  console.log("664",result);

    const refute=this.causalForm.get('refute')?.setValue(result.data.refute);
    console.log("causalForm",this.causalForm.get('refute')?.setValue(result.data.refute));

    const estimate=this.causalForm.get('estimated_effect')?.setValue(result.data.estimated_effect);
    console.log("577",this.causalForm.get('estimated_effect')?.setValue(result.data.estimated_effect));

    
    const effect=this.causalForm.get('new_effect')?.setValue(result.data.new_effect);
    console.log("causalForm",this.causalForm.get('new_effect')?.setValue(result.data.new_effect));

    const pvalue=this.causalForm.get('p_value')?.setValue(result.data.p_value);
    console.log("577",this.causalForm.get('p_value')?.setValue(result.data.p_value));

    const plotLayout = result.plot.layout
    Plotly.newPlot("plotDiv", plotData, plotLayout);
      
    })
  }

  getColumnValues(){
    let body = {
      "file_name":this.selectedFileName,
      "column_name": this.selectedTarget,
      "row_index": this.selectRecord
    }

    const projectValue = this.myForm.get('file_name')?.value;
    console.log("567",projectValue);
    console.log("568",body);
    const test = this.causalDiscoveryService.getColumnValues(this.token,body, (result: any) => {
      
      console.log("575",result);
      const x=this.myForm.get('target1')?.setValue(result);
      console.log("577",this.myForm.get('target1')?.setValue(result.data));
    });

  }
  setselectedFileNameFields(event:any)
  {

    this.selectedFileName= event.value;
    console.log("selectedFileName",this.selectedFileName);
  }
  setselectedRecordsFields(event:any)
  {

    this.selectRecord= event.value;;
    console.log("selectRecord",this.selectRecord);
  }
  setselectedTargetsFields(event:any)
  {

    this.selectedTarget= event.value;;
    console.log("selectedTarget",this.selectedTarget);
  }
  setselectedFileNameFields1(event:any)
  {
    if(this.myForm.get('project')?.value=="BioreactorData.csv"){
      this.batchTargetEnable=true;
    }else{
      this.batchTargetEnable=false;

    }
  }

  setDefaultValueBasedOnCondition() {
    if (this.myForm.get('project')?.value=="BioreactorData.csv") {
      this.typControl.setValue('your-selected-value'); // Set the selected value
    }
  }

 
  
  
  
  

  getWhatIfPredictionValue(){

    this.finalSliderValues = [];

    // Iterate through resultSliderDAta to push the final values into finalSliderValues array
    for (let result of this.resultSliderDAta) {
      this.finalSliderValues.push({
        feature: result.Feature,
        value: result.lastValue || result.Value // Use lastValue if available, otherwise use current Value
      });
    }
    console.log("759",this.finalSliderValues);
  
    let body = {
      "typ": this.myForm.get('typ')?.value,
      "pred": {
             
            
      },
      "d": {
             
      } as DObject
      
  }
 

  for (let sliderValue of this.finalSliderValues) {
    body.d[sliderValue.feature] = sliderValue.value;
  }
  
    //const projectValue = this.myForm.get('file_name')?.value;
    
    console.log("692",body);
    const test = this.causalDiscoveryService.getWhatIfPrediction(this.token,body, (result: any) => {
  
      this.PredictedPenicillinConcentrationForm.get('PredictedPenicillinConcentration')?.setValue(result.data.prediction.toFixed(2));
    
    });

  }
  onSliderChange(result: any) {
    
    console.log('Slider value changed: ',result.Feature, result.Value);
    result.lastValue = result.Value;
    console.log('Slider value changed: ',result.Feature, result.lastValue);
    // You can perform further operations here based on the slider value changes
  

    // Log the last values to the console or perform any other necessary action

}

setFormValues(formValues: any) {
  this.myForm = formValues;
}

getFormValues() {
  return this.myForm;
  console.log("947",this.myForm);
}

ngOnDestroy() {
  this.setFormValues(this.myForm.value);
}
  

}
